#ifndef START_H_INCLUDED
#define START_H_INCLUDED

void ClearCursor();
void ViewCursor();
void ResizeConsole();
void gotoxy(int x, int y);
void DisplayStart();
void printBound();

#endif // FIRSTSCREEN_H_INCLUDED
