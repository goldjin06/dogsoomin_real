#ifndef NAME_H_INCLUDED
#define NAME_H_INCLUDED

//void UserName(FILE *fp, char *nn);

#endif // DOGSOOMIN_H_INCLUDED
