
#ifndef NAME_H_INCLUDED
#define NAME_H_INCLUDED


void showTitle();
void UserName(FILE *fp, char *nn);
void selectStage();
void gameClear(FILE *fp, char *nn);
void maze();

#endif // DOGSOOMIN_H_INCLUDED
